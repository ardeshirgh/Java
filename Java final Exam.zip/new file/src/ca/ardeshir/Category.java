package ca.ardeshir;

public class Category {
    private int id;
    private String name;
    private int sub_cat_id;
    private int active;

    public Category(int id, String name, int sub_cat_id, int active) {
        this.id = id;
        this.name = name;
        this.sub_cat_id = sub_cat_id;
        this.active = active;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSub_cat_id() {
        return sub_cat_id;
    }

    public void setSub_cat_id(int sub_cat_id) {
        this.sub_cat_id = sub_cat_id;
    }

    public int getActive() {
        return active;
    }

    public void setActive(int active) {
        this.active = active;
    }
}
