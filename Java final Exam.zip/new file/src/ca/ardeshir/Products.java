package ca.ardeshir;

public class Products {

    private int id;
    private String name;
    private String description;
    private int price_id;
    private int currency_id;
    private int active;

    public int getActive() {
        return active;
    }

    public void setActive(int active) {
        this.active = active;
    }

    public Products(int active) {
        this.active = active;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getPrice_id() {
        return price_id;
    }

    public void setPrice_id(int price_id) {
        this.price_id = price_id;
    }

    public int getCurrency_id() {
        return currency_id;
    }

    public void setCurrency_id(int currency_id) {
        this.currency_id = currency_id;
    }

    public Products(int id, String name, String description, int price_id, int currency_id) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price_id = price_id;
        this.currency_id = currency_id;
    }
}
