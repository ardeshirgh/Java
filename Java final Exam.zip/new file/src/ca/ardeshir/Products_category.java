package ca.ardeshir;

public class Products_category {
    private int id;
    private int products_id;
    private int category_id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProducts_id() {
        return products_id;
    }

    public void setProducts_id(int products_id) {
        this.products_id = products_id;
    }

    public int getCategory_id() {
        return category_id;
    }

    public void setCategory_id(int category_id) {
        this.category_id = category_id;
    }

    public Products_category(int id, int products_id, int category_id) {
        this.id = id;
        this.products_id = products_id;
        this.category_id = category_id;
    }
}
