package ca.ardeshir;

import java.sql.SQLException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        DataSource ds = new DataSource();
        ds.open();
        Scanner sn = new Scanner(System.in);
        int userInput;

        do {

            System.out.println("\033[34m");
            System.out.println("_______________________________________________");
            System.out.println("SELECT ONE OF THEM PLEASE !");
            System.out.println("1 - GO TO THE CUSTOMERS");
            System.out.println("2 - GO TO THE PRODUCTS");
            System.out.println("3 - GO TO THE CATEGORIES");
            System.out.println("4 - GO TO THE PRODUCT CATEGORIES");
            System.out.println("5 - GO TO THE CARDS");
            System.out.println("6 - GO TO THE CARD DETAILS");
            System.out.println("7 - GO TO THE CURRENCY");
            System.out.println("8 - GO TO THE PRICE");
            System.out.println("9 - GO TO THE CURRENCY PRICE");
            System.out.println("10 - GO TO THE INVOICES");
            System.out.println("11 - GO TO THE INVOICES DETAILS");
            System.out.println("________________________________________________");
            System.out.println("\033[34m");

            userInput = sn.nextInt();
            sn.nextLine();
            switch (userInput) {

                case 1:
                    System.out.println("WHAT DO YOU WANT TO DO ?");
                    System.out.println("1 - SEE THE TABLE OF CUSTOMERS");
                    System.out.println("2 - INSERT DATA IN CUSTOMERS");
                    System.out.println("3 - UPDATE THE CUSTOMERS");
                    System.out.println("4 - DELETE THE CUSTOMERS");

                    int customerInput = sn.nextInt();

                    switch (customerInput) {
                        case 1:
                            System.out.println("\u001B[96m" + "Customers Table : " + "\u001B[0m");
                            ds.queryCustomer();

                            break;

                        case 2:
                            System.out.println(" INSERT CUSTOMER NAME");
                            String name = sn.next();

                            System.out.println("INSERT CUSTOMER NICKNAME");
                            String nickName = sn.next();

                            System.out.println("INSERT CUSTOMER EMAIL");
                            String email = sn.next();

                            System.out.println("INSERT CUSTOMER ADDRESS");
                            String address = sn.next();

                            System.out.println("INSERT CUSTOMER PHONE");
                            String phone = sn.next();


                            try {
                                ds.insertCustomers(name, nickName, email, address, phone);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                        case 3:
                            System.out.println(" INSERT CUSTOMER NAME");
                            String name1 = sn.next();

                            System.out.println("INSERT CUSTOMER NICKNAME");
                            String nickName1 = sn.next();

                            System.out.println("INSERT CUSTOMER EMAIL");
                            String email1 = sn.next();

                            System.out.println("INSERT CUSTOMER ADDRESS");
                            String address1 = sn.next();

                            System.out.println("INSERT CUSTOMER PHONE");
                            String phone1 = sn.next();

                            System.out.println("INSERT OLD NAME CUSTOMER");
                            String oldName = sn.next();

                            try {
                                ds.updateCustomers(name1, nickName1, email1, address1, phone1, oldName);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                        case 4:
                            try {

                                System.out.println(" INSERT CUSTOMER NAME");
                                String name2 = sn.next();

                                ds.deleteCustomers(name2);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                    }

                    break;

                case 2:
                    System.out.println("WHAT DO YOU WANT TO DO ?");
                    System.out.println("1 - SEE THE TABLE OF PRODUCTS");
                    System.out.println("2 - INSERT DATA IN PRODUCTS");
                    System.out.println("3 - UPDATE THE PRODUCTS");
                    System.out.println("4 - DELETE THE PRODUCTS");

                    int productInput = sn.nextInt();

                    switch (productInput) {
                        case 1:
                            System.out.println("\u001B[96m" + "Product Table : " + "\u001B[0m");
                            ds.queryProduct();
                            break;

                        case 2:

                            System.out.println("INSERT PRODUCT NAME");
                            String name = sn.next();

                            System.out.println("INSERT PRODUCT DESCRIPTION");
                            String description = sn.nextLine();
                            sn.nextLine();

                            System.out.println("INSERT PRICE ID");
                            ds.queryPrice();
                            int priceId = sn.nextInt();


                            System.out.println("INSERT CURRENCY ID");
                            ds.queryCurrency();
                            int currencyId = sn.nextInt();

                            try {
                                ds.insertProduct(name, description, priceId, currencyId);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());

                            }
                            break;

                        case 3:
                            System.out.println("INSERT PRODUCT NAME");
                            String name1 = sn.next();

                            System.out.println("INSERT PRODUCT DESCRIPTION");
                            String description1 = sn.nextLine();
                            sn.next();

                            System.out.println("INSERT PRICE ID");
                            ds.queryPrice();
                            int priceId1 = sn.nextInt();

                            System.out.println("INSERT CURRENCY ID");
                            ds.queryCurrency();
                            int currencyId1 = sn.nextInt();

                            System.out.println("INSERT OLD NAME");
                            String oldName = sn.next();

                            try {
                                ds.updateProduct(name1, description1, priceId1, currencyId1, oldName);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;

                        case 4:
                            System.out.println("INSERT PRODUCT NAME");
                            String name2 = sn.next();
                            try {
                                ds.deleteProduct(name2);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                    }

                    break;

                case 3:
                    System.out.println("WHAT DO YOU WANT TO DO ?");
                    System.out.println("1 - SEE THE TABLE OF CATEGORIES");
                    System.out.println("2 - INSERT DATA IN CATEGORIES");
                    System.out.println("3 - UPDATE THE CATEGORIES");
                    System.out.println("4 - DELETE THE CATEGORIES");

                    int categoryInput = sn.nextInt();

                    switch (categoryInput) {
                        case 1:
                            System.out.println("\u001B[96m" + "Category Table : " + "\u001B[0m");
                            ds.queryCategory();
                            break;
                        case 2:

                            System.out.println("INSERT THE CATEGORY NAME");
                            String name = sn.next();

                            System.out.println("INSERT THE SUB CATEGORY");
                            int subCategory = sn.nextInt();

                            try {
                                ds.insertCategory(name, subCategory);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());

                            }
                            break;
                        case 3:

                            System.out.println("INSERT THE CATEGORY NAME");
                            String name1 = sn.next();

                            System.out.println("INSERT THE SUB CATEGORY");
                            int subCategory1 = sn.nextInt();

                            System.out.println("INSERT THE CATEGORY OLD NAME");
                            String oldName = sn.next();

                            try {
                                ds.updateCategory(name1, subCategory1, oldName);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());

                            }
                            break;
                        case 4:

                            System.out.println("INSERT CATEGORY NAME");
                            String name2 = sn.next();
                            try {
                                ds.deleteCategory(name2);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                    }
                    break;

                case 4:
                    System.out.println("WHAT DO YOU WANT TO DO ?");
                    System.out.println("1 - SEE THE TABLE OF PRODUCT CATEGORIES");
                    System.out.println("2 - INSERT DATA IN PRODUCT CATEGORIES");


                    int productCategoryInput = sn.nextInt();

                    switch (productCategoryInput) {

                        case 1:
                            System.out.println("\u001B[96m" + "Product Category Table : " + "\u001B[0m");
                            ds.queryProductCategory();
                            break;
                        case 2:
                            System.out.println(" INSERT PRODUCT NAME");
                            String productName = sn.next();

                            System.out.println("INSERT PRODUCT DESCRIPTION");
                            String productDescription = sn.nextLine();

                            System.out.println("INSERT PRICE ID");
                            ds.queryPrice();
                            int priceId = sn.nextInt();

                            System.out.println("INSERT CURRENCY ID");
                            ds.queryCurrency();
                            int currencyId = sn.nextInt();

                            System.out.println("INSERT CATEGORY NAME");
                            String categoryName = sn.next();

                            System.out.println("INSERT SUB CATEGORY");
                            int subCategory = sn.nextInt();

                            try {
                                ds.insertProducts_Category(productName, productDescription, priceId, currencyId, categoryName, subCategory);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                    }

                    break;

                case 5:
                    System.out.println("WHAT DO YOU WANT TO DO ?");
                    System.out.println("1 - SEE THE TABLE OF CARDS");
                    System.out.println("2 - INSERT DATA IN CARDS");
                    System.out.println("3 - UPDATE THE CARDS");
                    System.out.println("4 - DELETE THE CARDS");

                    int cardInput = sn.nextInt();

                    switch (cardInput) {

                        case 1:
                            System.out.println("\u001B[96m" + "Card Table : " + "\u001B[0m");
                            ds.queryCard();
                            break;
                        case 2:
                            System.out.println("INSERT CUSTOMER ID");
                            ds.queryCustomer();
                            int customerId = sn.nextInt();

                            try {
                                ds.insertCards(customerId);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                        case 3:
                            System.out.println("INSERT CUSTOMER ID");
                            ds.queryCustomer();
                            int customerId1 = sn.nextInt();

                            System.out.println("INSERT THE OLD ID");
                            ds.queryCard();
                            int oldCard = sn.nextInt();

                            try {
                                ds.updateCards(customerId1, oldCard);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }

                            break;
                        case 4:
                            System.out.println("INSERT THE CUSTOMER ID");
                            ds.queryCustomer();
                            int CustomerId = sn.nextInt();
                            try {
                                ds.deleteCards(CustomerId);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                    }

                    break;

                case 6:
                    System.out.println("WHAT DO YOU WANT TO DO ?");
                    System.out.println("1 - SEE THE TABLE OF CARD DETAILS");
                    System.out.println("2 - INSERT DATA IN CARD DETAILS");
                    System.out.println("3 - UPDATE THE CARD DETAILS");
                    System.out.println("4 - DELETE THE CARD DETAILS");

                    int cardDetailsInput = sn.nextInt();

                    switch (cardDetailsInput) {

                        case 1:
                            System.out.println("\u001B[96m" + "Card details Table : " + "\u001B[0m");
                            ds.queryCard_details();
                            break;
                        case 2:

                            System.out.println("INSERT THE CARD ID");
                            ds.queryCard();
                            int cardId = sn.nextInt();

                            System.out.println("INSERT THE QUANTITY");
                            int quantity = sn.nextInt();

                            System.out.println("INSERT THE PRODUCT ID");
                            ds.queryProduct();
                            int productId = sn.nextInt();

                            System.out.println("INSERT THE CURRENCY ID");
                            ds.queryCurrency();
                            int currencyId = sn.nextInt();

                            System.out.println("INSERT THE PRICE ID");
                            ds.queryPrice();
                            int priceId = sn.nextInt();

                            System.out.println("INSERT THE TOTAL AMOUNT");
                            double totalAmount = sn.nextDouble();

                            try {
                                ds.insertCardDetails(cardId, quantity, productId, currencyId, priceId, totalAmount);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                        case 3:

                            System.out.println("INSERT THE CARD ID");
                            ds.queryCard();
                            int cardId1 = sn.nextInt();

                            System.out.println("INSERT THE QUANTITY");
                            int quantity1 = sn.nextInt();

                            System.out.println("INSERT THE PRODUCT ID");
                            ds.queryProduct();
                            int productId1 = sn.nextInt();

                            System.out.println("INSERT THE CURRENCY ID");
                            ds.queryCurrency();
                            int currencyId1 = sn.nextInt();

                            System.out.println("INSERT THE PRICE ID");
                            ds.queryPrice();
                            int priceId1 = sn.nextInt();

                            System.out.println("INSERT THE TOTAL AMOUNT");
                            double totalAmount1 = sn.nextDouble();

                            System.out.println("INSERT THE OLD ID");
                            ds.queryCard_details();
                            int oldId = sn.nextInt();
                            try {
                                ds.updateCardDetails(cardId1, quantity1, productId1, currencyId1, priceId1, totalAmount1, oldId);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                        case 4:

                            System.out.println("INSERT THE CARD DETAILS ID");
                            int cardDetails = sn.nextInt();
                            try {
                                ds.deleteCardDetails(cardDetails);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                    }

                    break;

                case 7:
                    System.out.println("WHAT DO YOU WANT TO DO ?");
                    System.out.println("1 - SEE THE TABLE OF CURRENCY");
                    System.out.println("2 - INSERT DATA IN CURRENCY");
                    System.out.println("3 - UPDATE THE CURRENCY");
                    System.out.println("4 - DELETE THE CURRENCY");

                    int currencyInput = sn.nextInt();

                    switch (currencyInput) {

                        case 1:
                            System.out.println("\u001B[96m" + "Currency Table : " + "\u001B[0m");
                            ds.queryCurrency();
                            break;
                        case 2:

                            System.out.println("INSERT THE CURRENCY NAME");
                            String name = sn.next();

                            System.out.println("INSERT THE CURRENCY CODE");
                            String code = sn.next();

                            System.out.println("INSERT THE CURRENCY SYMBOL");
                            String symbol = sn.next();
                            try {
                                ds.insertCurrency(name, code, symbol);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                        case 3:

                            System.out.println("INSERT THE CURRENCY NAME");
                            String name1 = sn.next();

                            System.out.println("INSERT THE CURRENCY CODE");
                            String code1 = sn.next();

                            System.out.println("INSERT THE CURRENCY SYMBOL");
                            String symbol1 = sn.next();

                            System.out.println("INSERT THE OLD NAME");
                            String oldName = sn.next();

                            try {
                                ds.updateCurrency(name1, code1, symbol1, oldName);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                        case 4:

                            System.out.println("INSERT THE CURRENCY NAME");
                            String name2 = sn.next();

                            try {
                                ds.deleteCurrency(name2);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }

                            break;
                    }

                    break;

                case 8:
                    System.out.println("WHAT DO YOU WANT TO DO ?");
                    System.out.println("1 - SEE THE TABLE OF PRICE");
                    System.out.println("2 - INSERT DATA IN PRICE");
                    System.out.println("3 - UPDATE THE PRICE");
                    System.out.println("4 - DELETE THE PRICE");

                    int priceInput = sn.nextInt();

                    switch (priceInput) {

                        case 1:
                            System.out.println("\u001B[96m" + "Price Table : " + "\u001B[0m");
                            ds.queryPrice();
                            break;
                        case 2:

                            System.out.println("INSERT THE PRODUCT ID");
                            int productId = sn.nextInt();

                            System.out.println("INSERT THE CURRENCY ID");
                            int currencyId = sn.nextInt();

                            System.out.println("INSERT THE VALUE");
                            double value = sn.nextDouble();

                            try {
                                ds.insertPrice(productId, currencyId, value);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                        case 3:

                            System.out.println("INSERT THE PRODUCT ID");
                            int productId1 = sn.nextInt();

                            System.out.println("INSERT THE CURRENCY ID");
                            int currencyId1 = sn.nextInt();

                            System.out.println("INSERT THE VALUE");
                            double value1 = sn.nextDouble();

                            System.out.println("INSERT THE OLD VALUE");
                            double oldValue = sn.nextDouble();

                            try {
                                ds.updatePrice(productId1, currencyId1, value1, oldValue);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                        case 4:

                            System.out.println("INSERT THE PRODUCT ID");
                            int productId2 = sn.nextInt();

                            try {
                                ds.deletePrice(productId2);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                    }

                    break;

                case 9:
                    System.out.println("WHAT DO YOU WANT TO DO ?");
                    System.out.println("1 - SEE THE TABLE OF CURRENCY PRICE");
                    System.out.println("2 - INSERT DATA IN CURRENCY PRICE");
                    System.out.println("3 - UPDATE THE CURRENCY PRICE");
                    System.out.println("4 - DELETE THE CURRENCY PRICE");

                    int currencyPriceInput = sn.nextInt();

                    switch (currencyPriceInput) {

                        case 1:
                            System.out.println("\u001B[96m" + "Currency Price Table : " + "\u001B[0m");
                            ds.queryCurrency_price();
                            break;
                        case 2:

                            System.out.println("INSERT THE CURRENCY ID");
                            int currencyId = sn.nextInt();

                            System.out.println("INSERT THE VALUE");
                            double value = sn.nextDouble();

                            try {
                                ds.insertCurrency_price(currencyId, value);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                        case 3:

                            System.out.println("INSERT THE CURRENCY ID");
                            int currencyId1 = sn.nextInt();

                            System.out.println("INSERT THE VALUE");
                            double value1 = sn.nextDouble();

                            System.out.println("INSERT THE OLD VALUE");
                            double oldValue = sn.nextDouble();

                            try {
                                ds.updateCurrency_price(currencyId1, value1, oldValue);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());

                            }
                            break;
                        case 4:

                            System.out.println("INSERT THE CURRENCY ID");
                            int currencyId2 = sn.nextInt();
                            try {
                                ds.deleteCurrency_price(currencyId2);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                    }

                    break;

                case 10:
                    System.out.println("WHAT DO YOU WANT TO DO ?");
                    System.out.println("1 - SEE THE TABLE OF INVOICES");
                    System.out.println("2 - INSERT DATA IN INVOICES");
                    System.out.println("3 - UPDATE THE INVOICES");
                    System.out.println("4 - DELETE THE INVOICES");

                    int invoiceInput = sn.nextInt();

                    switch (invoiceInput) {

                        case 1:
                            System.out.println("\u001B[96m" + "Invoice Table : " + "\u001B[0m");
                            ds.queryInvoices();
                            break;
                        case 2:

                            System.out.println("INSERT THE NAME");
                            String name = sn.next();

                            System.out.println("INSERT THE CUSTOMER ID");
                            int customerId = sn.nextInt();

                            System.out.println("INSERT THE INVOICE DATE");
                            String invoiceDate = sn.next();

                            System.out.println("INSERT THE DUE DATE");
                            String dueDate = sn.next();

                            System.out.println("INSERT THE VALUE");
                            double value = sn.nextDouble();

                            System.out.println("INSERT THE IF IT'S PAID OR NOT");
                            String isPaid = sn.next();

                            System.out.println("INSERT THE PAY METHOD");
                            String payMethod = sn.next();

                            try {
                                ds.insertInvoices(name, customerId, dueDate, invoiceDate, value, isPaid, payMethod);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                        case 3:

                            System.out.println("INSERT THE NAME");
                            String name1 = sn.next();

                            System.out.println("INSERT THE CUSTOMER ID");
                            int customerId1 = sn.nextInt();

                            System.out.println("INSERT THE INVOICE DATE");
                            String invoiceDate1 = sn.next();

                            System.out.println("INSERT THE DUE DATE");
                            String dueDate1 = sn.next();

                            System.out.println("INSERT THE VALUE");
                            double value1 = sn.nextDouble();

                            System.out.println("INSERT THE IF IT'S PAID OR NOT");
                            String isPaid1 = sn.next();

                            System.out.println("INSERT THE PAY METHOD");
                            String payMethod1 = sn.next();

                            System.out.println("INSERT THE OLD NAME");
                            String oldName = sn.next();
                            try {
                                ds.updateInvoices(name1, customerId1, dueDate1, invoiceDate1, value1, isPaid1, payMethod1, oldName);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                        case 4:

                            System.out.println("INSERT THE NAME");
                            String name2 = sn.next();

                            try {
                                ds.deleteInvoices(name2);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;
                    }

                    break;

                case 11:
                    System.out.println("WHAT DO YOU WANT TO DO ?");
                    System.out.println("1 - SEE THE TABLE OF INVOICES DETAILS");
                    System.out.println("2 - INSERT DATA IN INVOICES DETAILS");
                    System.out.println("3 - UPDATE THE INVOICES DETAILS");
                    System.out.println("4 - DELETE THE INVOICES DETAILS");

                    int invoiceDetailsInput = sn.nextInt();

                    switch (invoiceDetailsInput) {

                        case 1:
                            System.out.println("\u001B[96m" + "Invoice Details Table : " + "\u001B[0m");
                            ds.queryInvoice_details();
                            break;
                        case 2:

                            System.out.println("INSERT THE INVOICE ID");
                            ds.queryInvoices();
                            int invoiceId = sn.nextInt();

                            System.out.println("INSERT THE PRODUCT ID");
                            ds.queryProduct();
                            int productId = sn.nextInt();

                            System.out.println("INSERT THE PRODUCT QUANTITY");
                            int productsQuantity = sn.nextInt();

                            try {
                                ds.insertInvoice_details(invoiceId, productId, productsQuantity);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }

                            break;
                        case 3:

                            System.out.println("INSERT THE INVOICE ID");
                            ds.queryInvoices();
                            int invoiceId1 = sn.nextInt();

                            System.out.println("INSERT THE PRODUCT ID");
                            ds.queryProduct();
                            int productId1 = sn.nextInt();

                            System.out.println("INSERT THE PRODUCT QUANTITY");
                            int productsQuantity1 = sn.nextInt();

                            System.out.println("INSERT THE OL ID");
                            int oldId = sn.nextInt();

                            try {
                                ds.updateInvoice_details(invoiceId1, productId1, productsQuantity1, oldId);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }

                            break;
                        case 4:

                            System.out.println("INSERT THE INVOICE ID");
                            ds.queryInvoices();
                            int invoiceID = sn.nextInt();

                            try {
                                ds.deleteInvoice_details(invoiceID);
                            } catch (SQLException e) {
                                System.out.println(e.getMessage());
                            }
                    }
            }

        } while (userInput != 0);
    }
}

