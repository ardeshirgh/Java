package ca.ardeshir;

public class Card_details {

    private int id;
    private int card_id;
    private int quantity;
    private int product_id;
    private int currency_id;
    private int price_id;
    private double total_amount;
    private int active;

    public Card_details(int id, int card_id, int quantity, int product_id, int currency_id, int price_id, double total_amount, int active) {
        this.id = id;
        this.card_id = card_id;
        this.quantity = quantity;
        this.product_id = product_id;
        this.currency_id = currency_id;
        this.price_id = price_id;
        this.total_amount = total_amount;
        this.active = active;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCard_id() {
        return card_id;
    }

    public void setCard_id(int card_id) {
        this.card_id = card_id;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getProduct_id() {
        return product_id;
    }

    public void setProduct_id(int product_id) {
        this.product_id = product_id;
    }

    public int getCurrency_id() {
        return currency_id;
    }

    public void setCurrency_id(int currency_id) {
        this.currency_id = currency_id;
    }

    public int getPrice_id() {
        return price_id;
    }

    public void setPrice_id(int price_id) {
        this.price_id = price_id;
    }

    public double getTotal_amount() {
        return total_amount;
    }

    public void setTotal_amount(double total_amount) {
        this.total_amount = total_amount;
    }

    public int getActive() {
        return active;
    }

    public void setActive(int active) {
        this.active = active;
    }
}
