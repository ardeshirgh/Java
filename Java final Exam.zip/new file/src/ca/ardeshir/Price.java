package ca.ardeshir;

public class Price {

   private int id;
   private int productId;
   private int currencyId;
   private double value;
   private int active;

    public Price(int id, int productId, int currencyId, double value, int active) {
        this.id = id;
        this.productId = productId;
        this.currencyId = currencyId;
        this.value = value;
        this.active = active;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getCurrencyId() {
        return currencyId;
    }

    public void setCurrencyId(int currencyId) {
        this.currencyId = currencyId;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public int getActive() {
        return active;
    }

    public void setActive(int active) {
        this.active = active;
    }
}
