package ca.ardeshir;

public class Invoice_details {
    private int id;
    private int invoices_id;
    private int products_id;
    private int products_quantity;
    private int active;


    public Invoice_details(int id, int invoices_id, int products_id, int products_quantity, int active) {
        this.id = id;
        this.invoices_id = invoices_id;
        this.products_id = products_id;
        this.products_quantity = products_quantity;
        this.active = active;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getInvoices_id() {
        return invoices_id;
    }

    public void setInvoices_id(int invoices_id) {
        this.invoices_id = invoices_id;
    }

    public int getProducts_id() {
        return products_id;
    }

    public void setProducts_id(int products_id) {
        this.products_id = products_id;
    }

    public int getProducts_quantity() {
        return products_quantity;
    }

    public void setProducts_quantity(int products_quantity) {
        this.products_quantity = products_quantity;
    }

    public int getActive() {
        return active;
    }

    public void setActive(int active) {
        this.active = active;
    }
}
