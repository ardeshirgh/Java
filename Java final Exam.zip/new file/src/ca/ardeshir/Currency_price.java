package ca.ardeshir;

public class Currency_price {

 private int id;
 private int currency_id;
 private double value;
 private int active;

    public Currency_price(int id, int currency_id, double value, int active) {
        this.id = id;
        this.currency_id = currency_id;
        this.value = value;
        this.active = active;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCurrency_id() {
        return currency_id;
    }

    public void setCurrency_id(int currency_id) {
        this.currency_id = currency_id;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public int getActive() {
        return active;
    }

    public void setActive(int active) {
        this.active = active;
    }
}
