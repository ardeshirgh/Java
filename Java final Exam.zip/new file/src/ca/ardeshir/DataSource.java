package ca.ardeshir;

import java.sql.*;

class DataSource {
    private static Connection conn;


    void open() {
        try {
            String DATABASE_ASSIGNMENT = "assignment.db";
            String CONNECTION_STRING = "jdbc:sqlite:src/";
            conn = DriverManager.getConnection(CONNECTION_STRING + DATABASE_ASSIGNMENT);
        } catch (SQLException e) {
            System.out.println("couldn't connect to database: " + e.getMessage());
        }
    }


    //-------------------------- PRODUCT CATEGORY ----------------------------------

    void queryProductCategory() {

        try {

            String sb = "SELECT p.name AS Products,  pr.value AS Price, cu.code AS currency, c.name AS Category " +
                    "FROM products p JOIN price pr ON p.price_id = pr.id JOIN currency cu ON p.currency_id = cu.id " +
                    "JOIN products_category pc " +
                    "ON p.id = pc.products_id " +
                    "JOIN category c " +
                    "ON c.id = pc.category_id ";
            PreparedStatement ps = conn.prepareStatement(sb);

            ResultSet rs = ps.executeQuery();
            System.out.println("________________________________________________________________");
            System.out.format("%-25s %-15s %-10s %-10s\n", "Products", "Price", "currency", "Category");
            System.out.println("________________________________________________________________");
            while (rs.next()) {
                System.out.format("%-25s %-15.2f %-10s %-10s\n",
                        rs.getString("Products"),
                        rs.getDouble("Price"),
                        rs.getString("currency"),
                        rs.getString("category")
                );
            }
            System.out.println("_________________________________________________________________");


        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }


    }

    //-------------------------- PRODUCT ----------------------------------

    void queryProduct() {

        try {

            String sb = "SELECT p.id AS Id, p.name AS Product, pr.value AS Price, cu.code AS Currency " +
                    "FROM products p JOIN price pr ON p.price_id = pr.id " +
                    "JOIN currency cu ON p.currency_id = cu.id WHERE p.active = 1";
            PreparedStatement ps = conn.prepareStatement(sb);

            ResultSet rs = ps.executeQuery();
            System.out.println("_____________________________________________________________");
            System.out.format("%-10s %-25s %-15s %-10s\n", "id", "Products", "Price", "currency");
            System.out.println("_____________________________________________________________");
            while (rs.next()) {
                System.out.format("%-10s %-25s %-15.2f %-10s\n",
                        rs.getInt("Id"),
                        rs.getString("Product"),
                        rs.getDouble("Price"),
                        rs.getString("Currency"));

            }
            System.out.println("_____________________________________________________________");


        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    //------------------------ CATEGORY -----------------------------

    void queryCategory() {

        try {

            PreparedStatement ps = conn.prepareStatement("SELECT * FROM category WHERE active = 1");

            ResultSet rs = ps.executeQuery();
            System.out.println("___________________________________________________");
            System.out.format("%-10s %-25s %-10s \n", "id", "Category", "Sub cat id");
            System.out.println("___________________________________________________");
            while (rs.next()) {
                System.out.format("%-10s %-25s %-10s\n",
                        rs.getInt("Id"),
                        rs.getString("name"),
                        rs.getInt("subCategory"));

            }
            System.out.println("___________________________________________________");


        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    //------------------------ CARD -----------------------------

    void queryCard() {

        try {

            String sb = "SELECT c.id AS id, cu.name AS customer " +
                    "FROM card c JOIN customer cu ON c.customer_id = cu.id WHERE c.active = 1";
            PreparedStatement ps = conn.prepareStatement(sb);

            ResultSet rs = ps.executeQuery();
            System.out.println("________________________");
            System.out.format("%-10s %-25s \n", "id", "Customer");
            System.out.println("________________________");
            while (rs.next()) {
                System.out.format("%-10s %-25s \n",
                        rs.getInt("Id"),
                        rs.getString("customer"));

            }
            System.out.println("________________________");


        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    //------------------------ CARD DETAILS -----------------------------

    void queryCard_details() {

        try {

            String sb = "SELECT cd.id AS id, cd.card_id, p.name AS product, cu.code AS currency, cd.quantity, pr.value AS Price, cd.total_amount " +
                    "FROM card_details cd JOIN products p ON cd.product_id = p.id JOIN currency cu ON cd.currency_id = cu.id JOIN price pr ON cd.price_id = pr.id WHERE cd.active = 1";
            PreparedStatement ps = conn.prepareStatement(sb);

            ResultSet rs = ps.executeQuery();
            System.out.println("______________________________________________________________________________________________________________________________________");
            System.out.format("%-10s %-15s %-20s %-25s %-20s %-20s %-20s \n", "id", "Card Id", "Product", "Currency", "Quantity", "Price", "Total amount");
            System.out.println("______________________________________________________________________________________________________________________________________");
            while (rs.next()) {
                System.out.format("%-10s %-15s %-25s %-20s %-20s %-20s %-20s \n",
                        rs.getInt("Id"),
                        rs.getInt("card_id"),
                        rs.getString("product"),
                        rs.getString("currency"),
                        rs.getDouble("quantity"),
                        rs.getDouble("Price"),
                        rs.getDouble("total_amount"));

            }
            System.out.println("______________________________________________________________________________________________________________________________________");


        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    //------------------------ CURRENCY -----------------------------

    void queryCurrency() {

        try {

            PreparedStatement ps = conn.prepareStatement("SELECT * FROM Currency WHERE active = 1");

            ResultSet rs = ps.executeQuery();
            System.out.println("______________________________________________________");
            System.out.format("%-10s %-20s %-15s %-20s \n", "Id", "Name", "Code", "Symbol");
            System.out.println("______________________________________________________");
            while (rs.next()) {
                System.out.format("%-10s %-20s %-15s %-200s \n",
                        rs.getInt("Id"),
                        rs.getString("Name"),
                        rs.getString("Code"),
                        rs.getString("Symbol"));


            }
            System.out.println("______________________________________________________");

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    //------------------------ CURRENCY PRICE -----------------------------

    void queryCurrency_price() {

        try {

            String sb = "SELECT cp.id AS id, cp.value AS value, cu.code AS currency " +
                    "FROM currency_price cp JOIN currency cu ON cp.currency_id = cu.id WHERE cp.active = 1";
            PreparedStatement ps = conn.prepareStatement(sb);

            ResultSet rs = ps.executeQuery();
            System.out.println("________________________________________");
            System.out.format("%-10s %-20s %-15s \n", "Id", "Currency", "Value");
            System.out.println("________________________________________");
            while (rs.next()) {
                System.out.format("%-10s %-20s %-15s \n",
                        rs.getInt("Id"),
                        rs.getString("currency"),
                        rs.getDouble("value"));


            }
            System.out.println("________________________________________");

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    //------------------------ PRICE -----------------------------

    void queryPrice() {

        try {

            String sb = "SELECT p.id AS id, pr.name AS products, c.code AS currency, p.value AS value " +
                    "FROM price p JOIN products pr ON p.productId = pr.id JOIN currency c ON p.currencyId = c.id WHERE p.active = 1 ";
            PreparedStatement ps = conn.prepareStatement(sb);

            ResultSet rs = ps.executeQuery();
            System.out.println("_____________________________________________________________");
            System.out.format("%-10s %-20s %-15s %-15s \n", "Id", "Products", "Currency", "Value");
            System.out.println("_____________________________________________________________");
            while (rs.next()) {
                System.out.format("%-10s %-20s %-15s %-15.2f \n",
                        rs.getInt("Id"),
                        rs.getString("products"),
                        rs.getString("currency"),
                        rs.getDouble("value"));


            }
            System.out.println("_____________________________________________________________");

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    //------------------------ CUSTOMERS -----------------------------

    void queryCustomer() {

        try {

            PreparedStatement ps = conn.prepareStatement("SELECT * FROM Customer WHERE active = 1");

            ResultSet rs = ps.executeQuery();
            System.out.println("______________________________________________________________________________________________________");
            System.out.format("%-10s %-15s %-20s %-20s %-20s %-20s \n", "id", "Name", "Nick name", "Email", "Address", "Phone");
            System.out.println("______________________________________________________________________________________________________");
            while (rs.next()) {
                System.out.format("%-10s %-15s %-20s %-20s %-20s %-20s \n",
                        rs.getInt("Id"),
                        rs.getString("name"),
                        rs.getString("nickName"),
                        rs.getString("email"),
                        rs.getString("address"),
                        rs.getString("phone"));


            }
            System.out.println("______________________________________________________________________________________________________");


        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    //------------------------ INVOICE DETAILS -----------------------------

    void queryInvoice_details() {

        try {
            String sb = "SELECT ie.Id AS id, i.name AS invoices,  p.name AS products, ie.products_quantity " +
                    "FROM invoice_details ie JOIN invoices i ON ie.invoices_id = i.id JOIN products p ON ie.products_id = p.id WHERE ie.active = 1";
            PreparedStatement ps = conn.prepareStatement(sb);

            ResultSet rs = ps.executeQuery();
            System.out.println("___________________________________________________________________________");
            System.out.format("%-10s %-20s %-25s %-20s \n", "Id", "Invoices", "Products", "Products Quantity");
            System.out.println("___________________________________________________________________________");
            while (rs.next()) {
                System.out.format("%-10s %-20s %-25s %-20s \n",
                        rs.getInt("Id"),
                        rs.getString("invoices"),
                        rs.getString("products"),
                        rs.getDouble("products_quantity"));


            }
            System.out.println("___________________________________________________________________________");

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    //------------------------ INVOICES -----------------------------

    void queryInvoices() {

        try {

            PreparedStatement ps = conn.prepareStatement("SELECT * FROM invoices WHERE active = 1");

            ResultSet rs = ps.executeQuery();
            System.out.println("_______________________________________________________________________________________________________________________________");
            System.out.format("%-10s %-20s %-15s %-20s %-15s %-15s %-15s %-15s \n", "Id", "Customer Id", "Name", "Invoices Date", "Due Date", "Value", "Is paid", "Pay Method");
            System.out.println("_______________________________________________________________________________________________________________________________");
            while (rs.next()) {
                System.out.format("%-10s %-20s %-15s %-20s %-15s %-15s %-15s %-15s \n",
                        rs.getInt("Id"),
                        rs.getInt("customer_id"),
                        rs.getString("name"),
                        rs.getString("invoices_date"),
                        rs.getString("due_date"),
                        rs.getDouble("value"),
                        rs.getString("isPaid"),
                        rs.getString("payMethod"));


            }
            System.out.println("_______________________________________________________________________________________________________________________________");

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    //------------------------ INSERT PRODUCT -----------------------

    int insertProduct(String name, String description, int price_id, int currency_id) throws SQLException {

        PreparedStatement queryProduct = conn.prepareStatement("SELECT * FROM Products WHERE name = ?");
        PreparedStatement insertIntoProducts = conn.prepareStatement("INSERT INTO products (name, description, price_id, currency_id) VALUES(?,?,?,?)"
                , PreparedStatement.RETURN_GENERATED_KEYS);
        queryProduct.setString(1, name);
        ResultSet results = queryProduct.executeQuery();
        if (results.next()) {
            System.out.println(name + " already in a database");
            return results.getInt(1);
        } else {

            insertIntoProducts.setString(1, name);
            insertIntoProducts.setString(2, description);
            insertIntoProducts.setInt(3, price_id);
            insertIntoProducts.setInt(4, currency_id);


            int affectedRows = insertIntoProducts.executeUpdate();


            if (affectedRows != 1) {
                throw new SQLException("Couldn't insert product!");
            } else {
                System.out.println("successfully inserted : " + name);
            }

            ResultSet generatedKeys = insertIntoProducts.getGeneratedKeys();
            if (generatedKeys.next()) {
                return generatedKeys.getInt(1);
            } else {
                throw new SQLException("Couldn't get id for product");
            }

        }
    }

    //------------------------ UPDATE PRODUCT -----------------------

    void updateProduct(String name, String description, int price_id, int currency_id, String oldName) throws SQLException {
        PreparedStatement updateProducts = conn.prepareStatement("UPDATE products SET name = ?, description = ?, price_id = ?, currency_id = ? WHERE name = ?"
                , PreparedStatement.RETURN_GENERATED_KEYS);
        updateProducts.setString(1, name);
        updateProducts.setString(2, description);
        updateProducts.setInt(3, price_id);
        updateProducts.setInt(4, currency_id);
        updateProducts.setString(5, oldName);

        int affectedRows = updateProducts.executeUpdate();


        if (affectedRows != 1) {
            throw new SQLException("Couldn't update product!");
        } else {
            System.out.println("successfully updated : " + name);
        }

        ResultSet generatedKeys = updateProducts.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("Couldn't get id for product");
        }

    }

    //------------------------ DELETE PRODUCT -----------------------

    void deleteProduct(String name) throws SQLException {
        PreparedStatement updateProducts = conn.prepareStatement("UPDATE products SET  active = ? WHERE name = ?"
                , PreparedStatement.RETURN_GENERATED_KEYS);
        updateProducts.setInt(1, 0);
        updateProducts.setString(2, name);

        int affectedRows = updateProducts.executeUpdate();


        if (affectedRows != 1) {
            throw new SQLException("Couldn't delete product!");
        } else {
            System.out.println("successfully delete : " + name);
        }

        ResultSet generatedKeys = updateProducts.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("Couldn't get id for product");
        }

    }

    //------------------------ INSERT CATEGORY ----------------------------------

    int insertCategory(String name, int subCategory) throws SQLException {

        PreparedStatement queryCategory = conn.prepareStatement("SELECT * FROM Category WHERE name = ?");
        PreparedStatement insertIntoCategory = conn.prepareStatement("INSERT INTO category (name, subCategory) VALUES(?,?)"
                , PreparedStatement.RETURN_GENERATED_KEYS);

        queryCategory.setString(1, name);
        ResultSet result = queryCategory.executeQuery();
        if (result.next()) {
            System.out.println(name + " already in a database");
            return result.getInt("id");
        } else {

            insertIntoCategory.setString(1, name);
            insertIntoCategory.setInt(2, subCategory);


            int affectedRows = insertIntoCategory.executeUpdate();


            if (affectedRows != 1) {
                throw new SQLException("Couldn't insert category!");
            } else {
                System.out.println("successfully inserted : " + name);
            }
        }

        ResultSet generatedKeys = insertIntoCategory.getGeneratedKeys();
        if (generatedKeys.next()) {
            return generatedKeys.getInt(1);
        } else {
            throw new SQLException("Couldn't get id for Category");
        }
    }

    //------------------------ UPDATE CATEGORY ----------------------------------

    void updateCategory(String name, int subCategory, String oldName) throws SQLException {
        PreparedStatement updateCategory = conn.prepareStatement("UPDATE category SET name = ?, subCategory = ? WHERE name = ?"
                , PreparedStatement.RETURN_GENERATED_KEYS);
        updateCategory.setString(1, name);
        updateCategory.setInt(2, subCategory);
        updateCategory.setString(3, oldName);


        int affectedRows = updateCategory.executeUpdate();


        if (affectedRows != 1) {
            throw new SQLException("Couldn't update Category!");
        } else {
            System.out.println("successfully updated : " + name);
        }

        ResultSet generatedKeys = updateCategory.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("Couldn't get id for Category");
        }

    }

    //------------------------ DELETE CATEGORY ----------------------------------

    void deleteCategory(String name) throws SQLException {
        PreparedStatement updateCategory = conn.prepareStatement("UPDATE category SET active = ? WHERE name = ?"
                , PreparedStatement.RETURN_GENERATED_KEYS);
        updateCategory.setInt(1, 0);
        updateCategory.setString(2, name);


        int affectedRows = updateCategory.executeUpdate();


        if (affectedRows != 1) {
            throw new SQLException("Couldn't delete Category!");
        } else {
            System.out.println("successfully delete : " + name);
        }

        ResultSet generatedKeys = updateCategory.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("Couldn't get id for Category");
        }

    }

    //------------------------ INSERT PRODUCT-CATEGORY ----------------------------------


    void insertProducts_Category(String productName, String productDescription, int price_id, int currency_id, String categoryName, int subCategory) throws SQLException {

        PreparedStatement queryProducts_category = conn.prepareStatement("SELECT * FROM Products_Category WHERE products_id = ? AND category_id = ?");
        PreparedStatement insertIntoProducts_category = conn.prepareStatement("INSERT INTO products_category (products_id, category_id) VALUES(?,?)"
                , PreparedStatement.RETURN_GENERATED_KEYS);
        try {
            conn.setAutoCommit(false);

            int productId = insertProduct(productName, productDescription, price_id, currency_id);
            int categoryId = insertCategory(categoryName, subCategory);

            //Check if exist on product category already
            queryProducts_category.setInt(1, productId);
            queryProducts_category.setInt(2, categoryId);


            ResultSet pc = queryProducts_category.executeQuery();
            if (pc.next()) {
                throw new SQLException("This product and category already exist and linked in the database");
            }

            insertIntoProducts_category.setInt(1, productId);
            insertIntoProducts_category.setInt(2, categoryId);

            int affectedRows = insertIntoProducts_category.executeUpdate();

            if (affectedRows == 1) {
                System.out.println("Commitment completed successfully");
                conn.commit();
            } else {
                throw new SQLException("The product category insert failed");
            }

        } catch (SQLException e) {
            System.out.println("Insert product category exception: " + e.getMessage());
            try {
                System.out.println("Performing rollback");
                conn.rollback();
            } catch (SQLException e2) {
                System.out.println("rollback failed " + e2.getMessage());
            }
        } finally {
            try {
                System.out.println("Resetting default commit behavior");
                conn.setAutoCommit(true);
            } catch (SQLException e) {
                System.out.println("Couldn't reset auto-commit! " + e.getMessage());
            }
        }
    }

    //------------------------ INSERT CUSTOMERS ----------------------------------

    void insertCustomers(String name, String nickName, String email, String address, String phone) throws SQLException {

        PreparedStatement queryCustomer = conn.prepareStatement("SELECT * FROM Customer WHERE name = ?");
        PreparedStatement insertIntoCustomer = conn.prepareStatement("INSERT INTO customer (name, nickName, email, address, phone) VALUES(?,?,?,?,?)"
                , PreparedStatement.RETURN_GENERATED_KEYS);

        queryCustomer.setString(1, name);
        ResultSet result = queryCustomer.executeQuery();
        if (result.next()) {
            System.out.println(name + " already in a database");
            result.getInt(1);
            return;
        } else {
            insertIntoCustomer.setString(1, name);
            insertIntoCustomer.setString(2, nickName);
            insertIntoCustomer.setString(3, email);
            insertIntoCustomer.setString(4, address);
            insertIntoCustomer.setString(5, phone);


            int affectedRows = insertIntoCustomer.executeUpdate();

            if (affectedRows != 1) {
                throw new SQLException("Couldn't insert customers");
            } else {
                System.out.println("successfully inserted : " + name);
            }
        }

        ResultSet generatedKeys = insertIntoCustomer.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("couldn't get customer id");
        }
    }

    //------------------------ UPDATE CUSTOMERS ----------------------------------

    void updateCustomers(String name, String nickName, String email, String address, String phone, String OldName) throws SQLException {
        PreparedStatement updateCustomers = conn.prepareStatement("UPDATE customer SET name = ?, nickName = ?, email = ?, address = ?, phone = ? WHERE name = ?"
                , PreparedStatement.RETURN_GENERATED_KEYS);
        updateCustomers.setString(1, name);
        updateCustomers.setString(2, nickName);
        updateCustomers.setString(3, email);
        updateCustomers.setString(4, address);
        updateCustomers.setString(5, phone);
        updateCustomers.setString(6, OldName);


        int affectedRows = updateCustomers.executeUpdate();


        if (affectedRows != 1) {
            throw new SQLException("Couldn't update Customer!");
        } else {
            System.out.println("successfully updated : " + name);
        }

        ResultSet generatedKeys = updateCustomers.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("Couldn't get id for Customers");
        }

    }

    //------------------------ DELETE CUSTOMERS ----------------------------------

    void deleteCustomers(String name) throws SQLException {
        PreparedStatement updateCustomers = conn.prepareStatement("UPDATE customer SET active = ? WHERE name = ?"
                , PreparedStatement.RETURN_GENERATED_KEYS);
        updateCustomers.setInt(1, 0);
        updateCustomers.setString(2, name);


        int affectedRows = updateCustomers.executeUpdate();


        if (affectedRows != 1) {
            throw new SQLException("Couldn't delete Customer!");
        } else {
            System.out.println("successfully delete : " + name);
        }

        ResultSet generatedKeys = updateCustomers.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("Couldn't get id for Customers");
        }

    }

    //------------------------ INSERT CARDS ----------------------------------

    void insertCards(int customer_id) throws SQLException {

        PreparedStatement queryCards = conn.prepareStatement("SELECT * FROM Card WHERE id = ?");
        PreparedStatement insertIntoCards = conn.prepareStatement("INSERT INTO card (customer_id) VALUES(?)"
                , PreparedStatement.RETURN_GENERATED_KEYS);

        queryCards.setInt(1, customer_id);
        ResultSet results = queryCards.executeQuery();
        if (results.next()) {
            System.out.println(customer_id + " already in a database");
            results.getInt(1);
            return;
        } else {
            insertIntoCards.setInt(1, customer_id);


            int affectedRows = insertIntoCards.executeUpdate();

            if (affectedRows != 1) {
                throw new SQLException("Couldn't insert Cards");
            } else {
                System.out.println("successfully inserted : " + customer_id);
            }
        }

        ResultSet generatedKeys = insertIntoCards.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("Couldn't get cards id");
        }

    }

    //------------------------ UPDATE CARDS ----------------------------------

    void updateCards(int customer_id, int oldId) throws SQLException {
        PreparedStatement updateCards = conn.prepareStatement("UPDATE card SET customer_id = ? WHERE id = ?");
        updateCards.setInt(1, customer_id);
        updateCards.setInt(2, oldId);


        int affectedRows = updateCards.executeUpdate();


        if (affectedRows != 1) {
            throw new SQLException("Couldn't update Card!");
        } else {
            System.out.println("successfully updated : " + customer_id);
        }

    }

    //------------------------ DELETE CARDS ----------------------------------

    void deleteCards(int customer_id) throws SQLException {
        PreparedStatement updateCards = conn.prepareStatement("UPDATE card SET active = ? WHERE customer_id = ?");
        updateCards.setInt(1, 0);
        updateCards.setInt(2, customer_id);


        int affectedRows = updateCards.executeUpdate();


        if (affectedRows != 1) {
            throw new SQLException("Couldn't delete Card!");
        } else {
            System.out.println("successfully delete : " + customer_id);
        }

    }

    //------------------------ INSERT CARDS-DETAILS ----------------------------------

    void insertCardDetails(int card_id, int quantity, int product_id, int currency_id, int price_id, double total_amount) throws SQLException {

        PreparedStatement queryCardsDetails = conn.prepareStatement("SELECT * FROM Card_details WHERE id = ?");
        PreparedStatement insertIntoCardsDetails = conn.prepareStatement("INSERT INTO Card_details (card_id, quantity, product_Id, currency_id, price_id, total_amount) VALUES(?,?,?,?,?,?)"
                , PreparedStatement.RETURN_GENERATED_KEYS);

        queryCardsDetails.setInt(1, card_id);
        ResultSet result = queryCardsDetails.executeQuery();
        if (result.next()) {
            System.out.println(card_id + " already in a database");
            result.getInt(1);
            return;
        } else {
            insertIntoCardsDetails.setInt(1, card_id);
            insertIntoCardsDetails.setInt(2, quantity);
            insertIntoCardsDetails.setInt(3, product_id);
            insertIntoCardsDetails.setInt(4, currency_id);
            insertIntoCardsDetails.setInt(5, price_id);
            insertIntoCardsDetails.setDouble(6, total_amount);


            int affectedRows = insertIntoCardsDetails.executeUpdate();

            if (affectedRows != 1) {
                throw new SQLException("couldn't get cards details id");
            } else {
                System.out.println("successfully inserted : " + card_id);
            }
        }

        ResultSet generatedKeys = insertIntoCardsDetails.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("couldn't get cards details Id");
        }
    }

    //------------------------ UPDATE CARDS-DETAILS ----------------------------------

    void updateCardDetails(int card_id, int quantity, int product_id, int currency_id, int price_id, double total_amount, int oldId) throws SQLException {
        PreparedStatement updateCard_details = conn.prepareStatement("UPDATE Card_details SET card_id = ?, quantity = ?, product_id = ?, currency_id = ?, price_id = ?, total_amount = ? WHERE quantity = ?"
                , PreparedStatement.RETURN_GENERATED_KEYS);
        updateCard_details.setInt(1, card_id);
        updateCard_details.setInt(2, quantity);
        updateCard_details.setInt(3, product_id);
        updateCard_details.setInt(4, currency_id);
        updateCard_details.setInt(5, price_id);
        updateCard_details.setDouble(6, total_amount);
        updateCard_details.setInt(7, oldId);


        int affectedRows = updateCard_details.executeUpdate();


        if (affectedRows != 1) {
            throw new SQLException("Couldn't update Card_details!");
        } else {
            System.out.println("successfully updated : " + quantity);
        }

        ResultSet generatedKeys = updateCard_details.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("Couldn't get id for Card_details");
        }

    }

    //------------------------ DELETE CARDS-DETAILS ----------------------------------

    void deleteCardDetails(int card_id) throws SQLException {
        PreparedStatement updateCard_details = conn.prepareStatement("UPDATE Card_details SET active = ? WHERE card_id = ?"
                , PreparedStatement.RETURN_GENERATED_KEYS);
        updateCard_details.setInt(1, 0);
        updateCard_details.setInt(2, card_id);

        int affectedRows = updateCard_details.executeUpdate();


        if (affectedRows != 1) {
            throw new SQLException("Couldn't delete Card_details!");
        } else {
            System.out.println("successfully delete : " + card_id);
        }

        ResultSet generatedKeys = updateCard_details.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("Couldn't get id for Card_details");
        }

    }

    //------------------------ INSERT CURRENCY ----------------------------------

    void insertCurrency(String name, String code, String symbol) throws SQLException {

        PreparedStatement queryCurrency = conn.prepareStatement("SELECT * FROM currency WHERE name = ?");
        PreparedStatement insertIntoCurrency = conn.prepareStatement("INSERT INTO currency (name, code, symbol) VALUES(?,?,?)"
                , PreparedStatement.RETURN_GENERATED_KEYS);

        queryCurrency.setString(1, name);
        ResultSet result = queryCurrency.executeQuery();
        if (result.next()) {
            System.out.println(name + " already in a database");
            result.getInt(1);
            return;
        } else {
            insertIntoCurrency.setString(1, name);
            insertIntoCurrency.setString(2, code);
            insertIntoCurrency.setString(3, symbol);


            int affectedRows = insertIntoCurrency.executeUpdate();

            if (affectedRows != 1) {
                throw new SQLException("couldn't get cards details id");
            } else {
                System.out.println("successfully inserted : " + name);
            }
        }

        ResultSet generatedKeys = insertIntoCurrency.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("couldn't get cards details Id");
        }
    }

    //------------------------ UPDATE CURRENCY ----------------------------------

    void updateCurrency(String name, String code, String symbol, String oldName) throws SQLException {
        PreparedStatement updateCurrency = conn.prepareStatement("UPDATE currency SET name = ?, code = ?, symbol = ? WHERE name = ?"
                , PreparedStatement.RETURN_GENERATED_KEYS);
        updateCurrency.setString(1, name);
        updateCurrency.setString(2, code);
        updateCurrency.setString(3, symbol);
        updateCurrency.setString(4, oldName);


        int affectedRows = updateCurrency.executeUpdate();


        if (affectedRows != 1) {
            throw new SQLException("Couldn't update currency!");
        } else {
            System.out.println("successfully updated : " + code);
        }

        ResultSet generatedKeys = updateCurrency.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("Couldn't get id for currency");
        }

    }

    //------------------------ DELETE CURRENCY ----------------------------------

    void deleteCurrency(String name) throws SQLException {
        PreparedStatement updateCurrency = conn.prepareStatement("UPDATE currency SET active = ? WHERE name = ?"
                , PreparedStatement.RETURN_GENERATED_KEYS);
        updateCurrency.setInt(1, 0);
        updateCurrency.setString(2, name);

        int affectedRows = updateCurrency.executeUpdate();


        if (affectedRows != 1) {
            throw new SQLException("Couldn't delete currency!");
        } else {
            System.out.println("successfully delete : " + name);
        }

        ResultSet generatedKeys = updateCurrency.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("Couldn't get id for currency");
        }

    }

    //------------------------ INSERT PRICE ----------------------------------

    void insertPrice(int productId, int currencyId, double value) throws SQLException {

        PreparedStatement queryPrice = conn.prepareStatement("SELECT * FROM price WHERE id = ?");
        PreparedStatement insertIntoPrice = conn.prepareStatement("INSERT INTO price (productId, currencyId, value) VALUES(?,?,?)"
                , PreparedStatement.RETURN_GENERATED_KEYS);

        queryPrice.setInt(1, productId);
        ResultSet result = queryPrice.executeQuery();
        if (result.next()) {
            System.out.println(productId + " already in a database");
            result.getInt(1);
            return;
        } else {
            insertIntoPrice.setInt(1, productId);
            insertIntoPrice.setInt(2, currencyId);
            insertIntoPrice.setDouble(3, value);


            int affectedRows = insertIntoPrice.executeUpdate();

            if (affectedRows != 1) {
                throw new SQLException("couldn't get cards details id");
            } else {
                System.out.println("successfully inserted : " + productId);
            }
        }

        ResultSet generatedKeys = insertIntoPrice.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("couldn't get cards details Id");
        }
    }

    //------------------------ UPDATE PRICE ----------------------------------

    void updatePrice(int productId, int currencyId, double value, double oldValue) throws SQLException {
        PreparedStatement updatePrice = conn.prepareStatement("UPDATE price SET productId = ?, currencyId = ?, value = ? WHERE value = ?"
                , PreparedStatement.RETURN_GENERATED_KEYS);
        updatePrice.setInt(1, productId);
        updatePrice.setInt(2, currencyId);
        updatePrice.setDouble(3, value);
        updatePrice.setDouble(4, oldValue);


        int affectedRows = updatePrice.executeUpdate();


        if (affectedRows != 1) {
            throw new SQLException("Couldn't update price!");
        } else {
            System.out.println("successfully updated : " + value);
        }

        ResultSet generatedKeys = updatePrice.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("Couldn't get id for price");
        }

    }

    //------------------------ DELETE PRICE ----------------------------------

    void deletePrice(int productId) throws SQLException {
        PreparedStatement updatePrice = conn.prepareStatement("UPDATE price SET active = ? WHERE productId = ?"
                , PreparedStatement.RETURN_GENERATED_KEYS);
        updatePrice.setInt(1, 0);
        updatePrice.setInt(2, productId);

        int affectedRows = updatePrice.executeUpdate();


        if (affectedRows != 1) {
            throw new SQLException("Couldn't delete price!");
        } else {
            System.out.println("successfully delete : " + productId);
        }

        ResultSet generatedKeys = updatePrice.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("Couldn't get id for price");
        }

    }

    //------------------------ INSERT CURRENCY-PRICE ----------------------------------

    void insertCurrency_price(int currency_id, double value) throws SQLException {

        PreparedStatement queryCurrency_price = conn.prepareStatement("SELECT * FROM currency_price WHERE id = ?");
        PreparedStatement insertIntoCurrency_price = conn.prepareStatement("INSERT INTO currency_price (currency_id, value) VALUES(?,?)"
                , PreparedStatement.RETURN_GENERATED_KEYS);

        queryCurrency_price.setInt(1, currency_id);
        ResultSet result = queryCurrency_price.executeQuery();
        if (result.next()) {
            System.out.println(currency_id + " already in a database");
            result.getInt(1);
            return;
        } else {
            insertIntoCurrency_price.setInt(1, currency_id);
            insertIntoCurrency_price.setDouble(2, value);


            int affectedRows = insertIntoCurrency_price.executeUpdate();

            if (affectedRows != 1) {
                throw new SQLException("couldn't get Currency price details id");
            } else {
                System.out.println("successfully inserted : " + currency_id);
            }
        }

        ResultSet generatedKeys = insertIntoCurrency_price.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("couldn't get Currency price details Id");
        }
    }

    //------------------------ UPDATE CURRENCY-PRICE ----------------------------------

    void updateCurrency_price(int currency_id, double value, double oldValue) throws SQLException {
        PreparedStatement updatePrice = conn.prepareStatement("UPDATE currency_price SET  currency_id = ?, value = ? WHERE value = ?"
                , PreparedStatement.RETURN_GENERATED_KEYS);
        updatePrice.setInt(1, currency_id);
        updatePrice.setDouble(2, value);
        updatePrice.setDouble(3, oldValue);


        int affectedRows = updatePrice.executeUpdate();


        if (affectedRows != 1) {
            throw new SQLException("Couldn't update currency_price!");
        } else {
            System.out.println("successfully updated : " + value);
        }

        ResultSet generatedKeys = updatePrice.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("Couldn't get id for currency_price");
        }

    }

    //------------------------ DELETE CURRENCY-PRICE ----------------------------------

    void deleteCurrency_price(int currency_id) throws SQLException {
        PreparedStatement updatePrice = conn.prepareStatement("UPDATE currency_price SET  active = ? WHERE currency_id = ?"
                , PreparedStatement.RETURN_GENERATED_KEYS);
        updatePrice.setInt(1, 0);
        updatePrice.setDouble(2, currency_id);

        int affectedRows = updatePrice.executeUpdate();


        if (affectedRows != 1) {
            throw new SQLException("Couldn't delete currency_price!");
        } else {
            System.out.println("successfully delete : " + currency_id);
        }

        ResultSet generatedKeys = updatePrice.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("Couldn't get id for currency_price");
        }

    }

    //------------------------ INSERT INVOICES ----------------------------------

    void insertInvoices(String name, int customer_id, String due_date, String invoices_date, double value, String isPaid, String payMethod) throws SQLException {

        PreparedStatement queryInvoices = conn.prepareStatement("SELECT * FROM invoices WHERE name = ?");
        PreparedStatement insertIntoInvoices = conn.prepareStatement("INSERT INTO invoices (name, customer_id, due_date, invoices_date, value, isPaid, payMethod) VALUES(?,?,?,?,?,?,?)"
                , PreparedStatement.RETURN_GENERATED_KEYS);

        queryInvoices.setString(1, name);
        ResultSet result = queryInvoices.executeQuery();
        if (result.next()) {
            System.out.println(name + " already in a database");
            result.getInt(1);
            return;
        } else {
            insertIntoInvoices.setString(1, name);
            insertIntoInvoices.setInt(2, customer_id);
            insertIntoInvoices.setString(3, due_date);
            insertIntoInvoices.setString(4, invoices_date);
            insertIntoInvoices.setDouble(5, value);
            insertIntoInvoices.setString(6, isPaid);
            insertIntoInvoices.setString(7, payMethod);


            int affectedRows = insertIntoInvoices.executeUpdate();

            if (affectedRows != 1) {
                throw new SQLException("couldn't get cards details id");
            } else {
                System.out.println("successfully inserted : " + name);
            }
        }

        ResultSet generatedKeys = insertIntoInvoices.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("couldn't get cards details Id");
        }
    }

    //------------------------ UPDATE INVOICES ----------------------------------

    void updateInvoices(String name, int customer_id, String due_date, String invoices_date, double value, String isPaid, String payMethod, String oldName) throws SQLException {
        PreparedStatement updateInvoices = conn.prepareStatement("UPDATE invoices SET name = ?, customer_id = ?, due_date = ?, invoices_date = ?, value = ?, isPaid = ?, payMethod = ? WHERE name = ?"
                , PreparedStatement.RETURN_GENERATED_KEYS);
        updateInvoices.setString(1, name);
        updateInvoices.setInt(2, customer_id);
        updateInvoices.setString(3, due_date);
        updateInvoices.setString(4, invoices_date);
        updateInvoices.setDouble(5, value);
        updateInvoices.setString(6, isPaid);
        updateInvoices.setString(7, payMethod);
        updateInvoices.setString(8, oldName);


        int affectedRows = updateInvoices.executeUpdate();


        if (affectedRows != 1) {
            throw new SQLException("Couldn't update invoices!");
        } else {
            System.out.println("successfully updated : " + name);
        }

        ResultSet generatedKeys = updateInvoices.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("Couldn't get id for invoices");
        }

    }

    //------------------------ DELETE INVOICES ----------------------------------

    void deleteInvoices(String name) throws SQLException {
        PreparedStatement updateInvoices = conn.prepareStatement("UPDATE invoices SET active = ? WHERE name = ?"
                , PreparedStatement.RETURN_GENERATED_KEYS);
        updateInvoices.setInt(1, 0);
        updateInvoices.setString(2, name);

        int affectedRows = updateInvoices.executeUpdate();


        if (affectedRows != 1) {
            throw new SQLException("Couldn't delete invoices!");
        } else {
            System.out.println("successfully delete : " + name);
        }

        ResultSet generatedKeys = updateInvoices.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("Couldn't get id for invoices");
        }

    }

    //------------------------ INSERT INVOICE-DETAILS ----------------------------------

    void insertInvoice_details(int invoices_id, int products_id, int products_quantity) throws SQLException {

        PreparedStatement queryInvoice_details = conn.prepareStatement("SELECT * FROM invoice_details WHERE id = ?");
        PreparedStatement insertIntoInvoice_details = conn.prepareStatement("INSERT INTO invoice_details (invoices_id, products_id, products_quantity) VALUES(?,?,?)"
                , PreparedStatement.RETURN_GENERATED_KEYS);

        queryInvoice_details.setInt(1, invoices_id);
        ResultSet result = queryInvoice_details.executeQuery();
        if (result.next()) {
            System.out.println(invoices_id + " already in a database");
            result.getInt(1);
            return;
        } else {
            insertIntoInvoice_details.setInt(1, invoices_id);
            insertIntoInvoice_details.setInt(2, products_id);
            insertIntoInvoice_details.setInt(3, products_quantity);


            int affectedRows = insertIntoInvoice_details.executeUpdate();

            if (affectedRows != 1) {
                throw new SQLException("couldn't get cards details id");
            } else {
                System.out.println("successfully inserted : " + invoices_id);
            }
        }

        ResultSet generatedKeys = insertIntoInvoice_details.getGeneratedKeys();
        if (generatedKeys.next()) {
            generatedKeys.getInt(1);
        } else {
            throw new SQLException("couldn't get cards details Id");
        }
    }

    //------------------------ UPDATE INVOICE-DETAILS ----------------------------------

    void updateInvoice_details(int invoices_id, int products_id, int products_quantity, int oldId) throws SQLException {
        PreparedStatement updateInvoice_details = conn.prepareStatement("UPDATE invoice_details SET invoices_id = ?, products_id = ?, products_quantity = ? WHERE id = ?");
        updateInvoice_details.setInt(1, invoices_id);
        updateInvoice_details.setInt(2, products_id);
        updateInvoice_details.setInt(3, products_quantity);
        updateInvoice_details.setInt(4, oldId);


        int affectedRows = updateInvoice_details.executeUpdate();


        if (affectedRows != 1) {
            throw new SQLException("Couldn't update invoice_details!");
        } else {
            System.out.println("successfully updated : " + invoices_id);
        }


    }

    //------------------------ DELETE INVOICE-DETAILS ----------------------------------

    void deleteInvoice_details(int invoices_id) throws SQLException {
        PreparedStatement updateInvoice_details = conn.prepareStatement("UPDATE invoice_details SET active = ? WHERE invoices_id = ?");
        updateInvoice_details.setInt(1, 0);
        updateInvoice_details.setInt(2, invoices_id);

        int affectedRows = updateInvoice_details.executeUpdate();


        if (affectedRows != 1) {
            throw new SQLException("Couldn't delete invoice_details!");
        } else {
            System.out.println("successfully delete : " + invoices_id);
        }


    }

}












